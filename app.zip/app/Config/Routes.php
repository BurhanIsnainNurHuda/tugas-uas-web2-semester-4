<?php
use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// Handle semua preflight OPTIONS request (CORS)
$routes->options('(:any)', function() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method, Authorization');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
    header('HTTP/1.1 200 OK');
    exit();
});

// Endpoint API
$routes->group('api', function($routes) {
    // Endpoint Login (Public)
    $routes->post('login', 'Auth::login');
    
    // Endpoint CRUD Master Data (Protected by Auth Filter)
    $routes->group('', ['filter' => 'auth'], function($routes) {
        $routes->resource('barang');
        $routes->resource('kategori');
    });
});
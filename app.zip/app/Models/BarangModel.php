<?php namespace App\Models;
use CodeIgniter\Model;

class BarangModel extends Model {
    protected $table = 'barang';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id_kategori', 'nama_barang', 'stok', 'harga'];
}
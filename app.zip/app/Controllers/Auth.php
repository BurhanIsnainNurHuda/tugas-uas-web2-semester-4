<?php namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\UserModel;

class Auth extends ResourceController
{
    public function login()
    {
        $userModel = new UserModel();
        $data = $this->request->getJSON();

        // Validasi input tidak boleh kosong
        if (empty($data->username) || empty($data->password)) {
            return $this->failValidationErrors('Username dan password wajib diisi');
        }

        $user = $userModel->where('username', $data->username)->first();

        // Verifikasi password dengan password_verify (support bcrypt hash)
        if ($user && password_verify($data->password, $user['password'])) {
            // Generate token acak yang baru setiap login
            $newToken = bin2hex(random_bytes(32));

            // Simpan token baru ke database
            $userModel->update($user['id'], ['token' => $newToken]);

            return $this->respond([
                'status'  => true,
                'token'   => $newToken,
                'message' => 'Login Berhasil'
            ]);
        }

        return $this->failUnauthorized('Username atau Password salah');
    }
}
<?php namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\BarangModel;

class Barang extends ResourceController
{
    protected $modelName = 'App\Models\BarangModel';
    protected $format    = 'json';

    public function index() {
        // Ambil data barang join dengan kategori
        $db = \Config\Database::connect();
        $builder = $db->table('barang');
        $builder->select('barang.*, kategori.nama_kategori');
        $builder->join('kategori', 'kategori.id = barang.id_kategori');
        $data = $builder->get()->getResult();
        return $this->respond($data);
    }

    public function create() {
        $data = $this->request->getJSON();
        $this->model->insert($data);
        return $this->respondCreated(['message' => 'Barang berhasil ditambahkan']);
    }

    public function show($id = null) {
        return $this->respond($this->model->find($id));
    }

    public function update($id = null) {
        $data = $this->request->getJSON();
        $this->model->update($id, $data);
        return $this->respond(['message' => 'Barang berhasil diupdate']);
    }

    public function delete($id = null) {
        $this->model->delete($id);
        return $this->respondDeleted(['message' => 'Barang berhasil dihapus']);
    }
}
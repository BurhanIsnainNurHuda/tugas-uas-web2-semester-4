<?php 

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use App\Models\UserModel;
use Config\Services;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Ambil header Authorization
        $header = $request->getHeaderLine('Authorization');
        $token = null;

        // Cek apakah format header 'Bearer <token>' ada
        if (!empty($header) && preg_match('/Bearer\s(\S+)/', $header, $matches)) {
            $token = $matches[1];
        }

        // Jika tidak ada token, langsung kembalikan respon unauthorized
        if (is_null($token)) {
            return Services::response()
                ->setJSON(['status' => false, 'message' => 'Token tidak ditemukan'])
                ->setStatusCode(ResponseInterface::HTTP_UNAUTHORIZED);
        }

        // Cek ke database apakah token valid
        $userModel = new UserModel();
        $user = $userModel->where('token', $token)->first();

        // Jika token tidak ditemukan di database
        if (!$user) {
            return Services::response()
                ->setJSON(['status' => false, 'message' => 'Token tidak valid'])
                ->setStatusCode(ResponseInterface::HTTP_UNAUTHORIZED);
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) 
    {
        // Tidak perlu aksi apa-apa setelah request
    }
}
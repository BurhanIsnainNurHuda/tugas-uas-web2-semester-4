const { createApp, ref, onMounted } = Vue;
const { createRouter, createWebHashHistory } = VueRouter;

// =======================================
// KONFIGURASI AXIOS & INTERCEPTORS
// =======================================
axios.defaults.baseURL = 'http://localhost:8080/api';

axios.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
});

let isRedirecting = false;

axios.interceptors.response.use(response => response, error => {
    if (error.response && error.response.status === 401 && !isRedirecting) {
        isRedirecting = true;
        alert('Sesi habis atau akses ditolak. Silakan login!');
        localStorage.clear();
        window.location.hash = '#/login';
        setTimeout(() => { isRedirecting = false; }, 3000);
    }
    return Promise.reject(error);
});

// =======================================
// KOMPONEN: HALAMAN UTAMA (PUBLIC)
// =======================================
const Home = {
    template: `
        <div class="text-center bg-white p-10 rounded-lg shadow-md max-w-2xl mx-auto">
            <h2 class="text-4xl font-bold mb-4 text-gray-800">Selamat Datang di E-Inventory</h2>
            <p class="mb-8 text-gray-600">Sistem manajemen barang dengan Decoupled Architecture.</p>
            <router-link to="/login" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                Masuk sebagai Admin
            </router-link>
        </div>
    `
};

// =======================================
// KOMPONEN: LOGIN
// =======================================
const Login = {
    setup() {
        const username = ref('');
        const password = ref('');
        const router = VueRouter.useRouter();

        const handleLogin = async () => {
            try {
                const res = await axios.post('/login', {
                    username: username.value,
                    password: password.value
                });
                if (res.data.status) {
                    isRedirecting = false;
                    localStorage.setItem('isLoggedIn', 'true');
                    localStorage.setItem('token', res.data.token);
                    router.push('/dashboard');
                }
            } catch (error) {
                alert('Login Gagal! Cek kembali username/password.');
            }
        };

        return { username, password, handleLogin };
    },
    template: `
        <div class="max-w-md mx-auto bg-white p-8 rounded-lg shadow-md">
            <h2 class="text-2xl font-bold mb-6 text-center">Admin Login</h2>
            <form @submit.prevent="handleLogin">
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Username</label>
                    <input v-model="username" type="text" class="w-full border border-gray-300 p-2 rounded focus:outline-none focus:border-blue-500" required>
                </div>
                <div class="mb-6">
                    <label class="block text-gray-700 mb-2">Password</label>
                    <input v-model="password" type="password" class="w-full border border-gray-300 p-2 rounded focus:outline-none focus:border-blue-500" required>
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700 transition">Masuk</button>
            </form>
        </div>
    `
};

// =======================================
// KOMPONEN: DASHBOARD (CRUD BARANG)
// =======================================
const Dashboard = {
    setup() {
        const barangList = ref([]);
        const form = ref({ id_kategori: 1, nama_barang: '', stok: 0, harga: 0 });
        const isEditing = ref(false);
        const editId = ref(null);
        const isLoading = ref(false);

        // Mapping id_kategori ke nama (agar optimistic update bisa tampilkan nama kategori)
        const kategoriMap = {
            1: 'Elektronik',
            2: 'Alat Tulis',
            3: 'Pakaian'
        };

        const fetchBarang = async () => {
            if (isLoading.value) return;
            isLoading.value = true;
            try {
                const res = await axios.get('/barang');
                barangList.value = res.data;
            } catch (error) {
                console.error("Gagal load data", error);
            } finally {
                isLoading.value = false;
            }
        };

        const simpanBarang = async () => {
            const payload = { ...form.value };

            if (isEditing.value) {
                // Optimistic update: langsung ubah di list tanpa tunggu server
                const idx = barangList.value.findIndex(b => b.id === editId.value);
                if (idx !== -1) {
                    barangList.value[idx] = {
                        ...barangList.value[idx],
                        ...payload,
                        nama_kategori: kategoriMap[payload.id_kategori] || 'Lainnya'
                    };
                }
                resetForm();
                try {
                    await axios.put(`/barang/${editId.value}`, payload);
                } catch (error) {
                    alert('Gagal update, data dikembalikan.');
                    fetchBarang(); // rollback jika gagal
                }
            } else {
                // Optimistic insert: tambah sementara dengan id temporary
                const tempId = Date.now();
                const tempItem = {
                    id: tempId,
                    ...payload,
                    nama_kategori: kategoriMap[payload.id_kategori] || 'Lainnya'
                };
                barangList.value.push(tempItem);
                resetForm();
                try {
                    await axios.post('/barang', payload);
                    // Refresh untuk dapat id asli dari server
                    fetchBarang();
                } catch (error) {
                    alert('Gagal menyimpan data.');
                    barangList.value = barangList.value.filter(b => b.id !== tempId); // rollback
                }
            }
        };

        const editData = (item) => {
            isEditing.value = true;
            editId.value = item.id;
            form.value = {
                id_kategori: item.id_kategori,
                nama_barang: item.nama_barang,
                stok: item.stok,
                harga: item.harga
            };
        };

        const hapusData = async (id) => {
            if (confirm('Yakin ingin menghapus barang ini?')) {
                // Optimistic delete: langsung hapus dari list
                const backup = [...barangList.value];
                barangList.value = barangList.value.filter(b => b.id !== id);
                try {
                    await axios.delete(`/barang/${id}`);
                } catch (error) {
                    alert('Gagal menghapus data.');
                    barangList.value = backup; // rollback jika gagal
                }
            }
        };

        const resetForm = () => {
            isEditing.value = false;
            editId.value = null;
            form.value = { id_kategori: 1, nama_barang: '', stok: 0, harga: 0 };
        };

        onMounted(() => {
            fetchBarang();
        });

        return { barangList, form, isEditing, isLoading, simpanBarang, editData, hapusData, resetForm };
    },
    template: `
        <div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white p-6 rounded-lg shadow-md col-span-1 h-fit">
                    <h3 class="text-xl font-bold mb-4">{{ isEditing ? 'Edit Barang' : 'Tambah Barang' }}</h3>
                    <form @submit.prevent="simpanBarang">
                        <div class="mb-3">
                            <label class="block text-sm text-gray-700">Kategori (ID)</label>
                            <input v-model="form.id_kategori" type="number" class="w-full border p-2 rounded text-sm" required>
                        </div>
                        <div class="mb-3">
                            <label class="block text-sm text-gray-700">Nama Barang</label>
                            <input v-model="form.nama_barang" type="text" class="w-full border p-2 rounded text-sm" required>
                        </div>
                        <div class="mb-3 flex gap-2">
                            <div class="w-1/2">
                                <label class="block text-sm text-gray-700">Stok</label>
                                <input v-model="form.stok" type="number" class="w-full border p-2 rounded text-sm" required>
                            </div>
                            <div class="w-1/2">
                                <label class="block text-sm text-gray-700">Harga</label>
                                <input v-model="form.harga" type="number" class="w-full border p-2 rounded text-sm" required>
                            </div>
                        </div>
                        <div class="flex gap-2 mt-4">
                            <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded w-full">{{ isEditing ? 'Update' : 'Simpan' }}</button>
                            <button type="button" v-if="isEditing" @click="resetForm" class="bg-gray-400 text-white px-4 py-2 rounded w-full">Batal</button>
                        </div>
                    </form>
                </div>

                <div class="bg-white p-6 rounded-lg shadow-md col-span-2 overflow-x-auto">
                    <h3 class="text-xl font-bold mb-4">Daftar Barang</h3>
                    <div v-if="isLoading" class="text-center text-gray-400 py-4">Memuat data...</div>
                    <table v-else class="min-w-full table-auto border-collapse">
                        <thead>
                            <tr class="bg-gray-200 text-left text-sm uppercase text-gray-600">
                                <th class="p-3 border">No</th>
                                <th class="p-3 border">Nama Barang</th>
                                <th class="p-3 border">Kategori</th>
                                <th class="p-3 border">Stok</th>
                                <th class="p-3 border">Harga</th>
                                <th class="p-3 border">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item, index) in barangList" :key="item.id" class="border-b hover:bg-gray-50">
                                <td class="p-3 border">{{ index + 1 }}</td>
                                <td class="p-3 border">{{ item.nama_barang }}</td>
                                <td class="p-3 border">{{ item.nama_kategori }}</td>
                                <td class="p-3 border text-center">{{ item.stok }}</td>
                                <td class="p-3 border">Rp {{ item.harga.toLocaleString('id-ID') }}</td>
                                <td class="p-3 border flex gap-2">
                                    <button @click="editData(item)" class="bg-yellow-400 text-white px-2 py-1 rounded text-xs">Edit</button>
                                    <button @click="hapusData(item.id)" class="bg-red-500 text-white px-2 py-1 rounded text-xs">Hapus</button>
                                </td>
                            </tr>
                            <tr v-if="barangList.length === 0">
                                <td colspan="6" class="p-3 text-center text-gray-500">Belum ada data barang.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `
};

// =======================================
// ROUTING & APP INITIALIZATION
// =======================================
const routes = [
    { path: '/', component: Home },
    { path: '/login', component: Login },
    { path: '/dashboard', component: Dashboard, meta: { requiresAuth: true } }
];

const router = createRouter({
    history: createWebHashHistory(),
    routes
});

router.beforeEach((to, from, next) => {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (to.meta.requiresAuth && !isLoggedIn) {
        next('/login');
    } else {
        next();
    }
});

const app = createApp({
    methods: {
        logout() {
            localStorage.clear();
            this.$router.push('/login');
        }
    }
});

app.use(router);
app.mount('#app');